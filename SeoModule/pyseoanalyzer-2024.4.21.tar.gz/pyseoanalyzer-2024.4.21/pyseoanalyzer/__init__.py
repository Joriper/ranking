#!/usr/bin/env python3

from .analyzer import analyze
from .stemmer import stem